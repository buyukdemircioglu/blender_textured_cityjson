"""----------------------------------------------------------------------------

    Developed by Mehmet Büyükdemircioğlu

    Postdoctoral Researcher

    University of Twente, Faculty of Geo-information Science and Earth Observation (ITC)

    This code is part of 4TU.HERITAGE (https://www.4tu.nl/heritage/) project

    14.04.2025

    Linux version updated on 21.01.2026
----------------------------------------------------------------------------"""


bl_info = {
    "name": "Textured CityJSON Importer",
    "blender": (4, 4, 0),
    "category": "Import-Export",
    "author": "Mehmet Büyükdemircioğlu",
    "version": (1, 0, 2),
    "description": "Import CityJSON files with textured buildings using per-building atlas."
}

import glob
import bpy
import bmesh
import json
import os
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper
from mathutils import Vector


# ---------- CORE FUNCTIONS ----------

def find_case_insensitive(path):
    if os.path.exists(path):
        return path
    folder = os.path.dirname(path)
    base = os.path.basename(path)
    matches = glob.glob(os.path.join(folder, "*"))
    for m in matches:
        if os.path.basename(m).lower() == base.lower():
            return m
    return path  # will still fail, but at least you tried

def reproject_to_world_coordinates(vertices, scale, translate, surface_vertices):
    world_coords = []
    for ring in surface_vertices:
        gc = []
        for j in ring:
            x = vertices[j][0] * scale[0] + translate[0]
            y = vertices[j][1] * scale[1] + translate[1]
            z = vertices[j][2] * scale[2] + translate[2]
            gc.append((x, y, z))
        world_coords.append(gc)
    return world_coords

def get_surface_indices(surfaces):
    ground, walls, roof = [], [], []
    for idx, val in enumerate(surfaces):
        if val == 0:
            ground.append(idx)
        elif val == 3:
            roof.append(idx)
        else:
            walls.append(idx)
    return ground, walls, roof

def get_surface_vertices(boundaries, g_idx, w_idx, r_idx):
    g = [boundaries[i][0] for i in g_idx]
    w = [boundaries[i][0] for i in w_idx]
    r = [boundaries[i][0] for i in r_idx]
    return g, w, r

def create_mesh(name, verts, faces, uvs, texture_path, collection):
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)

    # Flatten vertices and UVs while ensuring uniqueness per vertex-uv pair
    vert_dict = {}
    mesh_verts = []
    mesh_faces = []
    mesh_uvs = []

    for face, face_uv in zip(faces, uvs):
        face_indices = []
        for v_co, uv_co in zip(face, face_uv):
            key = (tuple(v_co), tuple(uv_co))
            if key not in vert_dict:
                vert_dict[key] = len(mesh_verts)
                mesh_verts.append(v_co)
                mesh_uvs.append(uv_co)
            face_indices.append(vert_dict[key])
        mesh_faces.append(face_indices)

    mesh.from_pydata(mesh_verts, [], mesh_faces)
    mesh.update()

    # Set UV coordinates explicitly
    mesh.uv_layers.new(name="UVMap")
    uv_layer = mesh.uv_layers.active.data
    loop_index = 0
    for face in mesh.polygons:
        for vert_idx in face.vertices:
            uv_layer[loop_index].uv = mesh_uvs[vert_idx]
            loop_index += 1

    # Material and texture setup
    mat = bpy.data.materials.new(name + "_Mat")
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    tex_image = mat.node_tree.nodes.new("ShaderNodeTexImage")

    if texture_path and os.path.exists(texture_path):
        tex_image.image = bpy.data.images.load(texture_path)
    else:
        print(f"Texture not found or path is None: {texture_path}")

    #mat.node_tree.links.new(bsdf.inputs['Base Color'], tex_image.outputs['Color'])
    mat.node_tree.links.new(tex_image.outputs['Color'], bsdf.inputs['Base Color'])
    mesh.materials.append(mat)

    return obj


# ---------- OPERATOR ----------

class IMPORT_OT_cityjson(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.cityjson"
    bl_label = "Import Textured CityJSON"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        with open(self.filepath) as f:
            cityjson = json.load(f)

        scale = cityjson["transform"]["scale"]
        translate = cityjson["transform"]["translate"]
        vertices = cityjson["vertices"]
        texverts = cityjson.get("appearance", {}).get("vertices-texture", [])

        parent_collection = bpy.data.collections.new("CityJSON_Buildings")
        bpy.context.scene.collection.children.link(parent_collection)

        for obj_id, obj in cityjson["CityObjects"].items():
            if obj["type"] != "BuildingPart" or not obj_id.endswith("-0"):
                continue

            geom = obj["geometry"][0]
            surfaces = geom["semantics"]["values"][0]
            boundaries = geom["boundaries"][0]
            textures = geom.get("texture", {}).get("rgbTexture", {}).get("values", [])

            all_faces = []
            all_uv_faces = []

            for face_idx, face_boundary in enumerate(boundaries):
                vertex_indices = face_boundary[0]
                face_coords = [(
                    vertices[vi][0] * scale[0] + translate[0],
                    vertices[vi][1] * scale[1] + translate[1],
                    vertices[vi][2] * scale[2] + translate[2]
                ) for vi in vertex_indices]

                uv_coords = []
                if face_idx < len(textures) and textures[face_idx]:
                    tex_face = textures[face_idx][0]
                    if tex_face and len(tex_face) > 1:
                        uv_indices = tex_face[1:]
                        uv_coords = [texverts[idx] for idx in uv_indices]

                if len(uv_coords) != len(face_coords):
                    uv_coords = [(0.0, 0.0)] * len(face_coords)

                all_faces.append(face_coords)
                all_uv_faces.append(uv_coords)

            # Correct texture atlas per-building
            tex_idx = None
            for face_tex in textures:
                if face_tex and face_tex[0] and isinstance(face_tex[0][0], int):
                    tex_idx = face_tex[0][0]
                    break

            if tex_idx is not None:
                texture_list = cityjson.get("appearance", {}).get("textures", [])
                if tex_idx < len(texture_list):
                    texture_relpath = texture_list[tex_idx]["image"]
                    texture_relpath = texture_relpath.replace("\\", "/")
                    texture_path = os.path.normpath(os.path.join(os.path.dirname(self.filepath), texture_relpath))
                    texture_path = find_case_insensitive(texture_path)
                    #texture_path = os.path.join(os.path.dirname(self.filepath), texture_relpath)
                else:
                    texture_path = None
            else:
                texture_path = None

            building_collection = bpy.data.collections.new(obj_id)
            parent_collection.children.link(building_collection)
            create_mesh(obj_id, vertices, all_faces, all_uv_faces, texture_path, building_collection)

        self.report({'INFO'}, "Textured CityJSON import complete.")
        return {'FINISHED'}



# ---------- PANEL ----------

class IMPORT_PT_cityjson_panel(bpy.types.Panel):
    bl_label = "Textured CityJSON Importer"
    bl_idname = "IMPORT_PT_cityjson_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'CityJSON'

    def draw(self, context):
        layout = self.layout
        layout.operator("import_scene.cityjson")


# ---------- REGISTER ----------

def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_cityjson.bl_idname, text="CityJSON (.json)")

def register():
    bpy.utils.register_class(IMPORT_OT_cityjson)
    bpy.utils.register_class(IMPORT_PT_cityjson_panel)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

def unregister():
    bpy.utils.unregister_class(IMPORT_OT_cityjson)
    bpy.utils.unregister_class(IMPORT_PT_cityjson_panel)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
